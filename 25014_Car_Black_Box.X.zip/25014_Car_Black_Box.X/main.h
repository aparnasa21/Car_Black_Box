/* 
 * File:   main.h
 * Author: 25014
 *
 * Created on 26 November, 2025, 5:53 PM
 */

#ifndef MAIN_H
#define	MAIN_H
#include "adc.h"
#include "digital_keypad.h"
#include "clcd.h"
#include "i2c.h"
#include "ds1307.h"
#include "external_eeprom.h"
#include "password.h"
#include "external_eeprom.h"
#include "log.h"
#include "menu.h"

void dashboard(unsigned char key);
unsigned char set_time(unsigned char key);
unsigned char change_password(unsigned char key);
//void password(unsigned char key);
//void menu(unsigned char key);
//void event_read();


#endif	/* MAIN_H */

