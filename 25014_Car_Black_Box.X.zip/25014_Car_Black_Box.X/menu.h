#ifndef MENU_H
#define MENU_H

unsigned char menu(unsigned char key);

#endif
