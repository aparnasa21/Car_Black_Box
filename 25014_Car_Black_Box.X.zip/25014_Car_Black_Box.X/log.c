#include <xc.h>
#include "main.h"
#include "log.h"

unsigned char store_addr = 0;
unsigned char event_count = 0;

/* ---------- wait until every button is released ---------- */
void wait_key_release(void)
{    
    unsigned char t = 0;
    __delay_ms(50);
    while (read_digital_keypad(LEVEL_DETECTION) != ALL_RELEASED && t < 100)
    {
        __delay_ms(10);
        t++;
    }
    __delay_ms(50);
}

/* ---------- store one event in the external EEPROM ---------- */
void event_store(unsigned char *clock_reg, char *gear, unsigned char *speed)
{
    char entry[ENTRY_LEN];
    unsigned char i;

    entry[0]  = ((clock_reg[0] >> 4) & 0x03) + '0';
    entry[1]  = (clock_reg[0] & 0x0F) + '0'; 
    entry[2]  = ':';
    entry[3]  = ((clock_reg[1] >> 4) & 0x07) + '0';
    entry[4]  = (clock_reg[1] & 0x0F) + '0';
    entry[5]  = ':';
    entry[6]  = ((clock_reg[2] >> 4) & 0x07) + '0';
    entry[7]  = (clock_reg[2] & 0x0F) + '0';
    entry[8]  = gear[0];
    entry[9]  = gear[1];
    entry[10] = speed[0];
    entry[11] = speed[1];

    for (i = 0; i < ENTRY_LEN; i++)
        write_external_eeprom(store_addr + i, entry[i]);

    store_addr += ENTRY_LEN;
    if (store_addr >= LOG_SIZE * ENTRY_LEN)
        store_addr = 0;

    if (event_count < LOG_SIZE)
        event_count++;
}

/* ---------- read ONE stored event into buf as "0 12:00:00 ON 00" ---------- */
/* i = 0 is the oldest stored event, event_count-1 is the newest */
static void read_entry(unsigned char i, char *buf)
{
    unsigned char j, start;
    unsigned int addr;

    start = (event_count < LOG_SIZE) ? 0 : store_addr;   // when full, oldest is at store_addr

    addr = start + (unsigned int)i * ENTRY_LEN;
    if (addr >= LOG_SIZE * ENTRY_LEN)
        addr -= LOG_SIZE * ENTRY_LEN;

    buf[0] = i + '0';
    buf[1] = ' ';
    for (j = 0; j < 8; j++)
        buf[2 + j] = read_external_eeprom((unsigned char)(addr + j));
    buf[10] = ' ';
    buf[11] = read_external_eeprom((unsigned char)(addr + 8));
    buf[12] = read_external_eeprom((unsigned char)(addr + 9));
    buf[13] = ' ';
    buf[14] = read_external_eeprom((unsigned char)(addr + 10));
    buf[15] = read_external_eeprom((unsigned char)(addr + 11));
    buf[16] = '\0';
}

/* ---------- UART (for Tera Term), 9600 baud @ 20 MHz ---------- */
static void init_uart(void)
{
    TRISC6 = 1;          // TX/RX pins must be set as inputs for the EUSART
    TRISC7 = 1;
    SPBRG = 129;         // 20000000 / (16 * 9600) - 1
    BRGH = 1;
    SYNC = 0;
    SPEN = 1;
    TXEN = 1;
    CREN = 1;
}

static void uart_putch(char c)
{
    unsigned int t = 0; 
    while (!TXIF && ++t < 60000) // give up instead of hanging
    TXREG = c;
}

static void uart_puts(const char *s)
{
    while (*s)
        uart_putch(*s++);
}

/* ---------- 1) VIEW LOG ---------- */
/* returns: 3 = stay here, 2 = back to menu */
unsigned char view_log(unsigned char key)
{
    static unsigned char first_time = 1;
    static unsigned char idx = 0;
    unsigned char redraw = 0;
    char line[17];

    if (first_time)
    {
        first_time = 0;
        idx = 0;
        clear_display();
        if (event_count == 0)
            clcd_print("No log found", LINE1(0));
        else
            redraw = 1;
    }

    if (key == SW5)                          // exit to menu
    {
        first_time = 1;
        clear_display();
        return 2;
    }

    if (event_count == 0)
        return 3;

    if (key == SW1)                          // scroll up
    {
        idx = (idx == 0) ? event_count - 1 : idx - 1;
        redraw = 1;
        wait_key_release();
    }
    else if (key == SW2)                     // scroll down
    {
        idx = (idx + 1 >= event_count) ? 0 : idx + 1;
        redraw = 1;
        wait_key_release();
    }

    if (redraw)
    {
        read_entry(idx, line);
        clcd_print("L TIME     EV SP", LINE1(0));
        clcd_print(line, LINE2(0));
    }
    return 3;
}

/* ---------- 2) DOWNLOAD LOG ---------- */
unsigned char download_log(void)
{
    unsigned char i;
    char line[17];

    init_uart();
    clear_display();

    if (event_count == 0)
    {
        clcd_print("No log found", LINE1(0));
        uart_puts("No log found\r\n");
    }
    else
    {
        uart_puts("L TIME     EV SP\r\n");
        for (i = 0; i < event_count; i++)
        {
            read_entry(i, line);
            uart_puts(line);
            uart_puts("\r\n");
        }
        clcd_print("Download log", LINE1(0));
        clcd_print("Successful", LINE2(0));
    }

    __delay_ms(2000);
    clear_display();
    return 2;                                // back to menu
}

/* ---------- 3) CLEAR LOG ---------- */
unsigned char clear_log(void)
{
    event_count = 0;
    store_addr = 0;

    clear_display();
    clcd_print("Clear log", LINE1(0));
    clcd_print("Successful", LINE2(0));
    
    init_uart();
    uart_puts("Clear log successful\r\n");

    __delay_ms(2000);
    clear_display();
    return 2;// back to menu
}