

//DKP1 ='1'
//DKP2 ='0'
//DKP3 = back to dashboard
//void password(unsigned char key){
    
//}

#include <xc.h>
#include <string.h>
#include "main.h"
#include "password.h"

#define MAX_ATTEMPTS   3
#define BLOCK_SECONDS  60

//declare character original password[5]="1010";
char original_password[5] = "1010";
//declare user_psswd[5];
char user_password[5];

static unsigned char count = 0;  // keys entered so far
static unsigned char attempts_left = MAX_ATTEMPTS;
static unsigned char blocked = 0;
static unsigned long block_start = 0;// seconds since midnight
static unsigned char first_time = 1;// 1 = draw screen on next call

void clear_display(void)
{
    clcd_print("                ", LINE1(0));
    clcd_print("                ", LINE2(0));
}

/* RTC time as seconds since midnight */
static unsigned long now_seconds(void)
{
    unsigned char t[3];
    unsigned long h, m, s;

    get_time(t);
    h = ((t[0] >> 4) & 0x03) * 10 + (t[0] & 0x0F);
    m = ((t[1] >> 4) & 0x07) * 10 + (t[1] & 0x0F);
    s = ((t[2] >> 4) & 0x07) * 10 + (t[2] & 0x0F);

    return h * 3600UL + m * 60UL + s;
}

static unsigned char still_blocked(void)
{
    unsigned long now = now_seconds();
    unsigned long elapsed;

    if (now >= block_start)
        elapsed = now - block_start;
    else
        // passed midnight
        elapsed = now + 86400UL - block_start;   

    return elapsed < BLOCK_SECONDS;
}

/* Returns the next screen: 0 = dashboard, 1 = stay here, 2 = menu */
unsigned char login(unsigned char key)
{
    if (first_time)
    {
        first_time = 0;
        count = 0;
        clear_display();

        if (blocked)
        {
            if (still_blocked())
            {
                clcd_print("Please wait for", LINE1(0));
                clcd_print("a minute", LINE2(0));
                __delay_ms(2000);
                first_time = 1;
                clear_display();
                return 0;
            }
            // block time is over
            blocked = 0;                    
            attempts_left = MAX_ATTEMPTS;
        }
        clcd_print("Enter password", LINE1(1));
    }
    // back to dashboard
    if (key == SW3)                         
    {
        first_time = 1;
        clear_display();
        return 0;
    }
    else if (key == SW1 || key == SW2)
    {
        user_password[count] = (key == SW1) ? '1' : '0';
        clcd_putch('*', LINE2(6 + count));
        count++;
        
        // wait until the button is fully released (stops double reads)
        __delay_ms(50);
        while (read_digital_keypad(LEVEL_DETECTION) != ALL_RELEASED);
        __delay_ms(50);
    }
    // all 4 keys entered
    if (count == 4)                         
    {
        user_password[4] = '\0';
         // let the 4th * be seen
        __delay_ms(300);                   

        if (strcmp(user_password, original_password) == 0)
        {
            attempts_left = MAX_ATTEMPTS;
            first_time = 1;
            clear_display();
            // correct -> menu
            return 2;                       
        }

        attempts_left--;
        clear_display();
        clcd_print("Wrong password", LINE1(1));

        if (attempts_left == 0)
        {
            blocked = 1;
            block_start = now_seconds();
            clcd_print("Blocked 1 minute", LINE2(0));
            __delay_ms(2000);
            first_time = 1;
            clear_display();
            // blocked -> dashboard
            return 0;                       
        }

        if (attempts_left == 1)
            clcd_print("1 attempt left", LINE2(0));
        else
            clcd_print("2 attempts left", LINE2(0));

        __delay_ms(2000);
        // redraw the password screen
        first_time = 1;                     
    }
    return 1;
}
    
    /* returns: 7 = stay here, 2 = back to menu */
unsigned char change_password(unsigned char key)
{
    static unsigned char first_time = 1;
    static unsigned char n = 0;
    static char new_password[5];

    if (first_time)
    {
        first_time = 0;
        n = 0;
        clear_display();
        clcd_print("New password", LINE1(2));
    }

    if ((key == SW1 || key == SW2) && n < 4)
    {
        new_password[n] = (key == SW1) ? '1' : '0';
        clcd_putch('*', LINE2(6 + n));
        n++;
        wait_key_release();
    }
    else if (key == SW4)                     // save and back to menu
    {
        if (n == 4)
        {
            new_password[4] = '\0';
            strcpy(original_password, new_password);
            clear_display();
            clcd_print("Password saved", LINE1(1));
            __delay_ms(2000);
            first_time = 1;
            clear_display();
            return 2;
        }
        clear_display();                     // fewer than 4 keys entered
        clcd_print("Enter 4 keys", LINE1(2));
        __delay_ms(1500);
        first_time = 1;                      // restart this screen
    }
    else if (key == SW5)                     // exit without saving
    {
        first_time = 1;
        clear_display();
        return 2;
    }
    return 7;
}



