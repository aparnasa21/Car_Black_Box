#ifndef LOG_H
#define LOG_H

#define LOG_SIZE   10
#define ENTRY_LEN  12

extern unsigned char store_addr;
extern unsigned char event_count;

void event_store(unsigned char *clock_reg, char *gear, unsigned char *speed);
void wait_key_release(void);
unsigned char view_log(unsigned char key);
unsigned char download_log(void);
unsigned char clear_log(void);

#endif