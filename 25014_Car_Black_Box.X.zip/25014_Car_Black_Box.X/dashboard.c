/*
 * File:   dashboard.c
 * Author: 25014
 *
 * Created on 31 December, 2025
 */
#include <xc.h>
#include "main.h"
unsigned char clock_reg[3], speed[3] = {0};
char  *event[ ] = { "ON",  "GN", "G1", "G2", "G3", "G4", "G5", "GR", "C "};
int pos = 0;
unsigned int adc_val;

extern unsigned char operation;       // CHANGED: was "unsigned", must match main.c

void dashboard(unsigned char key) {

        int old_pos = pos;                      // NEW: remember the gear before the keys change it
        static unsigned char first_time = 1;    // NEW: for the power-on event

        clcd_print(" TIME     EV  SP", LINE1(0));

        // display time
        get_time(clock_reg);
        display_time(clock_reg);

        // event display ( Gear pos and speed )

        //Check if sw1 is pressed if yes increment the pos+1
        if(key == SW1){
            if (pos < 7)//0-7
                pos++;

            else if (pos == 8)
                pos = 1;

        }
        else if (key == SW2){

            if (pos == 8)
                pos = 0;
            if(pos > 0)//7-0
                pos--;

        }

        else if (key == SW3){
            pos = 8;
        }
        //if sw2 is pressed then decrement the pos-1

        clcd_print(event[pos] ,LINE2(10));

        //display speed
        //read the adc value from potentiometer
                //display speed
        adc_val = read_adc(CHANNEL0);                   // 0-1023
        adc_val = (adc_val * 99UL) / 1023;              // 00-99

        speed[0] = (unsigned char)((adc_val / 10) + '0');
        speed[1] = (unsigned char)((adc_val % 10) + '0');
        speed[2] = '\0';

        clcd_print((char *)speed, LINE2(14));

        // store events (speed is ready by now)
        if (first_time) {
            first_time = 0;
            event_store(clock_reg, event[pos], speed);
        }
        else if (key == SW3 || pos != old_pos) {
            event_store(clock_reg, event[pos], speed);
        }

        // TEMPORARY TEST - remove later: SW5 shows the last stored entry
        if (key == SW5) {
            char buf[13];
            unsigned char a, i;
            a = (store_addr == 0) ? (LOG_SIZE - 1) * ENTRY_LEN : store_addr - ENTRY_LEN;
            for (i = 0; i < ENTRY_LEN; i++)
                buf[i] = read_external_eeprom(a + i);
            buf[12] = '\0';
            clcd_print(buf, LINE1(0));
            __delay_ms(2000);
            clear_display();
        }

        if (key == SW4) {
            operation = 1;
        }
}
#define BLINK_LOOPS 150      // bigger = slower blinking

/* returns: 6 = stay here, 2 = back to menu */
unsigned char set_time(unsigned char key)
{
    static unsigned char first_time = 1;
    static unsigned char hour, min, sec, field;
    static unsigned int blink = 0;
    char line[9];

    if (first_time)
    {
        first_time = 0;
        get_time(clock_reg);
        hour = ((clock_reg[0] >> 4) & 0x03) * 10 + (clock_reg[0] & 0x0F);
        min  = ((clock_reg[1] >> 4) & 0x07) * 10 + (clock_reg[1] & 0x0F);
        sec  = ((clock_reg[2] >> 4) & 0x07) * 10 + (clock_reg[2] & 0x0F);
        field = 0;
        blink = 0;
        clear_display();
        clcd_print("HH:MM:SS", LINE1(0));
    }

    if (key == SW1)                          // increment the selected field
    {
        if (field == 0)      { hour++; if (hour > 23) hour = 0; }
        else if (field == 1) { min++;  if (min > 59)  min = 0; }
        else                 { sec++;  if (sec > 59)  sec = 0; }
        wait_key_release();
    }
    else if (key == SW2)                     // change field
    {
        field++;
        if (field > 2)
            field = 0;
        wait_key_release();
    }
    else if (key == SW4)                     // save and exit (BCD into the RTC)
    {
        write_ds1307(HOUR_ADDR, ((hour / 10) << 4) | (hour % 10));
        write_ds1307(MIN_ADDR,  ((min  / 10) << 4) | (min  % 10));
        write_ds1307(SEC_ADDR,  ((sec  / 10) << 4) | (sec  % 10));
        first_time = 1;
        clear_display();
        return 2;
    }
    else if (key == SW5)                     // exit without saving
    {
        first_time = 1;
        clear_display();
        return 2;
    }

    line[0] = (hour / 10) + '0';
    line[1] = (hour % 10) + '0';
    line[2] = ':';
    line[3] = (min / 10) + '0';
    line[4] = (min % 10) + '0';
    line[5] = ':';
    line[6] = (sec / 10) + '0';
    line[7] = (sec % 10) + '0';
    line[8] = '\0';

    blink++;
    if ((blink / BLINK_LOOPS) % 2)           // blank the selected field every other period
    {
        line[field * 3] = ' ';
        line[field * 3 + 1] = ' ';
    }

    clcd_print(line, LINE2(0));
    return 6;
}
