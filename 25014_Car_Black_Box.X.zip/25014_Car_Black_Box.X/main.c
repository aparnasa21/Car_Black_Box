/*
 * File:   main.c
 * Author: 25014
 *
 * Created on 31 December, 2025
 */

#pragma config WDTE = OFF

#include <xc.h> 
#include "main.h"

void init_config()
{
    init_adc();
    init_clcd();
    init_digital_keypad();
    init_i2c(100000); 
    init_ds1307();
}

unsigned char key, operation = 0;

void main(void) {
    init_config();
    
      
    while(1)
    {
        key = read_digital_keypad(STATE);
        
        if(key == SW4 && operation == 0)// only from the dashboard
        {
            operation = 1;
        }      
               
        if(operation == 0)
        {
            dashboard(key);
        }
        else if(operation == 1)
        {
            // login screen
             operation = login(key); 
        }
        else if(operation == 2)
        {
            // menu part
            operation = menu(key);
        }
        else if (operation == 3){
            operation = view_log(key);
        }
        else if (operation == 4){
            operation = download_log();
        }
        else if (operation == 5){
            operation = clear_log();
        }
        else if (operation == 6){
            operation = set_time(key);
        }
        else if (operation == 7){
            operation = change_password(key);
        }
           
    }
}
