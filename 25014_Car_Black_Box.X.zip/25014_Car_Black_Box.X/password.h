#ifndef PASSWORD_H
#define PASSWORD_H

unsigned char login(unsigned char key);
void clear_display(void);

#endif