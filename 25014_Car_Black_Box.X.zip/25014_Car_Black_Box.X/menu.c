#include <xc.h>
#include "main.h"
#include "menu.h"

#define MENU_COUNT 5

const char *menu_items[MENU_COUNT] = {
    "View log",
    "Download log",
    "Clear log",
    "Set time",
    "Change passwd"
};

/* draw one menu line: marker + name, padded to 16 characters */
static void print_line(unsigned char addr, unsigned char item, unsigned char selected)
{
    char buf[17];
    unsigned char i = 0, j = 0;

    buf[i++] = selected ? '*' : ' ';
    buf[i++] = ' ';
    while (menu_items[item][j] != '\0' && i < 16)
        buf[i++] = menu_items[item][j++];
    while (i < 16)
        buf[i++] = ' ';
    buf[16] = '\0';

    clcd_print(buf, addr);
}

/* Returns next screen: 2 = stay in menu, 0 = dashboard,
   3 = view log, 4 = download log, 5 = clear log, 6 = set time, 7 = change password */
unsigned char menu(unsigned char key)
{
    static unsigned char first_time = 1;
    static unsigned char sel = 0;      // selected item
    static unsigned char top = 0;      // item shown on line 1
    unsigned char redraw = 0;

    if (first_time)
    {
        first_time = 0;
        sel = 0;
        top = 0;
        clear_display();
        redraw = 1;
    }

    if (key == SW5)                    // scroll down
    {
        if (sel < MENU_COUNT - 1)
        {
            sel++;
            if (sel > top + 1)
                top = sel - 1;
            redraw = 1;
        }
        wait_key_release();
    }
    else if (key == SW4)               // scroll up
    {
        if (sel > 0)
        {
            sel--;
            if (sel < top)
                top = sel;
            redraw = 1;
        }
        wait_key_release();
    }
    else if (key == SW2)               // exit to dashboard
    {
        first_time = 1;
        clear_display();
        return 0;
    }
    else if (key == SW1)               // enter selected item
    {
        first_time = 1;
        return 3 + sel;
    }

    if (redraw)
    {
        print_line(LINE1(0), top,     (sel == top));
        print_line(LINE2(0), top + 1, (sel == top + 1));
    }
    return 2;
}
